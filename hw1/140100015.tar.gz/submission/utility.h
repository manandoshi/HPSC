#ifndef UTILITY_H
#define UTILITY_H
#endif

double integral(int num_points, char method);
double trapezoidal(int num_points);
double mc(int num_points);
