To generate the report, run

bash main_script.sh
